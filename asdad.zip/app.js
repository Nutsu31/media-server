require("dotenv").config();

const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");

const {
  server: { port },
  db: { dbUri },
  stripeConf: { stripe_secret },
} = require("./src/config/index");

const authRouter = require("./src/controllers/auth-cotroller");
const paymentRouter = require("./src/controllers/payment-controller");
const updateStatus = require("./src/controllers/updateStatus-controller");
const stripeResponse = require("./src/controllers/stripeResponse-controller");

const connectDB = require("./src/db/index");

//db instance
connectDB(dbUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

app.use("/auth", authRouter);
app.use("/pay", paymentRouter);
app.use("/update-status", updateStatus);
app.use("/stripe-res", stripeResponse);

// app.post(
//   "/webhook",
//   express.raw({ type: "application/json" }),
//   async (req, res) => {
//     const payload = req.body;
//     const sig = req.headers["stripe-signature"];

//     let event;

//     try {
//       event = stripe.webhooks.constructEvent(
//         payload,
//         sig,
//         process.env.STRIPE_SECRET_KEY
//       );
//     } catch (err) {
//       console.error("Webhook signature verification failed.", err);
//       return res.status(400).send("Webhook Error: Invalid signature.");
//     }

//     // Handle the specific event type
//     switch (event.type) {
//       case "checkout.session.completed":
//         const session = event.data.object;
//         // Payment was successful, handle the logic here
//         // Update your database, send confirmation emails, etc.
//         console.log("Payment succeeded:", session);
//         break;
//       // Handle other event types if needed
//       default:
//         console.log("Received event:", event.type);
//     }

//     console.log(event);
//     res.status(200).end();
//   }
// );

app.listen(port, () => console.log(`App is up and working on port ${port}`));
